# Topic 1 – Introduction to Retell AI & Creating Your First Agent

This repository contains supporting documentation and an optional n8n webhook workflow for the Topic 1 Retell AI LMS assessment.

## Assessment objective

Create, configure, test, and validate a basic Retell AI voice agent by configuring an LLM prompt, selecting a voice, setting a welcome message, completing a browser-based test call, and reviewing call history, transcript, and available performance metrics.

## Repository contents

```text
Retell-AI-Topic-1-Assessment/
├── README.md
├── documentation/
│   └── Topic_1_Retell_AI_Assessment_Explanation.pdf
├── workflow/
│   └── Retell_AI_Topic1_Call_Event_Logger_n8n.json
├── screenshots/
│   └── Add your own assessment screenshots here
└── demo/
    └── Add your Loom/YouTube demo link in video-link.txt
```

## Retell AI implementation summary

1. Sign in to the Retell AI workspace.
2. Open **Agents** and create a **Voice Agent** using a single prompt (Retell LLM).
3. Select an available LLM/model, voice, and language.
4. Add the agent instructions in the prompt editor. The example agent in this assessment is a general customer-support assistant.
5. Configure **Welcome Message** so the AI speaks first and set a custom greeting.
6. Save the configuration and run **Test Audio**. Allow browser microphone access.
7. Test greeting, basic questions, polite responses, and conversation closing.
8. End the test call, open **Call History**, and inspect the call record, transcript, and latency/performance information available in the account.
9. Publish the agent when the configuration has been checked.

## Optional n8n workflow

The JSON in `workflow/` is a starter webhook workflow. It accepts a POST request at the n8n webhook path `retell-call-events`, normalizes selected call fields, and returns a JSON acknowledgement.

### Import into n8n

1. Open n8n.
2. Create or open a workflow.
3. Choose **Import from File** (or the equivalent workflow import option).
4. Select `Retell_AI_Topic1_Call_Event_Logger_n8n.json`.
5. Save the workflow.
6. Open the **Retell Webhook** node and copy its Test URL for initial testing.
7. Send a sample POST request to the Test URL, then inspect the execution output.
8. For live events, activate the workflow and configure the corresponding production webhook URL in the Retell webhook/event settings supported by your account.

**Important:** This is an optional extension, not a required item in the supplied Topic 1 assessment brief. The workflow receives and acknowledges webhook events; it does not itself create or configure the Retell voice agent, and it does not write records to a database or spreadsheet. Confirm the event payload format against the Retell webhook event you configure. Do not expose webhook URLs, API keys, phone numbers, recordings, or private caller data in a public repository.

## Evidence to add

Add screenshots captured from your own Retell workspace. Suggested filenames:

- `screenshots/01-dashboard.png`
- `screenshots/02-agent-prompt-and-model.png`
- `screenshots/03-voice-and-language.png`
- `screenshots/04-welcome-message.png`
- `screenshots/05-successful-test-call.png`
- `screenshots/06-call-history.png`
- `screenshots/07-transcript-and-latency.png`

Only mark transcript and latency review complete after checking the actual call details. Do not invent metric values or include personal/customer information without permission; redact sensitive details before publishing.

## Demo video

The LMS brief identifies a Loom/YouTube demo video as mandatory. Record a short walkthrough showing the agent, prompt/model, voice, welcome message, test conversation, and call-history review. Add the share link to `demo/video-link.txt` and ensure the video permissions allow the assessor to view it.

## Submission checklist

- [ ] Agent configuration completed and saved
- [ ] Voice and welcome message verified
- [ ] Browser test call completed successfully
- [ ] Call History reviewed
- [ ] Transcript reviewed
- [ ] Available latency/performance metrics reviewed
- [ ] Screenshots added and sensitive details redacted
- [ ] Demo video recorded and link tested
- [ ] PDF documentation included
- [ ] Repository visibility and assessor access checked

## Notes

The PDF in `documentation/` explains the seven assessment exercises and the expected evidence. Replace or supplement this starter repository with your own screenshots and observed test results before submitting it.
